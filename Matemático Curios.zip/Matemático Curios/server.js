const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

// Le decimos a Express que sirva todos los archivos de la carpeta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Ruta principal: cuando entres a http://localhost:3000 cargará el index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Iniciamos el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en: http://localhost:${PORT}`);
});
