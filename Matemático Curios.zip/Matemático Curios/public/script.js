document.getElementById('boton').addEventListener('click', function() {
    // 1. Capturar la semilla del DOM
    const entradaSemilla = document.getElementById('entradaSemilla');
    let S = parseInt(entradaSemilla.value);

    // Validación del rango según el enunciado (1 <= S < 10000)
    if (isNaN(S) || S < 1 || S >= 10000) {
        alert("Por favor, ingrese una semilla válida entre 1 y 9999.");
        return;
    }

    // 2. Inicializar el vector con la semilla inicial
    let secuencia = [S];

    // 3. Bucle matemático de la conjetura
    while (S > 1) {
        if (S % 2 === 0) {
            S = S / 2; // Par: mitad
        } else {
            S = S * 3 + 1; // Impar: triple más uno
        }
        secuencia.push(S); // Guardamos en el vector
    }

    // 4. Procesar métricas del vector
    const largoSecuencia = secuencia.length;
    const numeroMaximo = Math.max(...secuencia);

    // 5. Renderizar resultados modificando el DOM
    document.getElementById('largo').innerText = largoSecuencia;
    document.getElementById('maximo').innerText = numeroMaximo;
    document.getElementById('secuencia').innerText = secuencia.join(' → ');

    // Mostrar el contenedor de resultados
    document.getElementById('cajaResultados').style.display = 'block';
});
