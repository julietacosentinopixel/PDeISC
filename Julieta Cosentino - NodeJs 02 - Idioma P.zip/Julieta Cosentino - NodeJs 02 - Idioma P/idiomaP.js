const readline = require('readline');

const interfazConsola = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});


function convertirAIdiomaP(textoOriginal) {
    let textoProcesado = "";
    const letrasVocales = "aeiouáéíóúAEIOUÁÉÍÓÚ";



    for (let posicion = 0; posicion < textoOriginal.length; posicion++) {
        let letraActual = textoOriginal.charAt(posicion);



        if (letrasVocales.includes(letraActual)) {
            if (letraActual === letraActual.toUpperCase()) {
                textoProcesado += letraActual + "P" + letraActual;
            }
            else {
                textoProcesado += letraActual + "p" + letraActual;
            }
        } 
        else {
            textoProcesado += letraActual;
        }
    }


    return textoProcesado;
}
interfazConsola.on('line', (lineaIngresada) => {
    const textoTraducido = convertirAIdiomaP(lineaIngresada);
    console.log(textoTraducido);
    interfazConsola.close();
});